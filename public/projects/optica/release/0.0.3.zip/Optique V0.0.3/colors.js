const selectionColor = "#367AFF";
const hoverColor = "#55AAFF"
const red = "#DD2222"